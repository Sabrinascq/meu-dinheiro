/**
 * Valida os dados de entrada de uma movimentação financeira.
 * @param {string} descricao
 * @param {number|string} valor
 * @param {string} tipo - 'receita' ou 'despesa'
 */
export function validarTransacao(descricao, valor, tipo) {
  if (!descricao || typeof descricao !== 'string' || descricao.trim().length < 2) {
    return { valido: false, erro: 'A descrição deve ter pelo menos 2 caracteres.' };
  }

  const valorNumerico = Number(valor);
  if (isNaN(valorNumerico) || valorNumerico <= 0) {
    return { valido: false, erro: 'O valor deve ser um número maior que zero.' };
  }

  if (tipo !== 'receita' && tipo !== 'despesa') {
    return { valido: false, erro: 'O tipo deve ser "receita" ou "despesa".' };
  }

  return { valido: true, erro: null };
}

/**
 * Cria um objeto de transação padronizado após validação.
 */
export function criarTransacao(descricao, valor, tipo) {
  const validacao = validarTransacao(descricao, valor, tipo);
  if (!validacao.valido) {
    throw new Error(validacao.erro);
  }

  return {
    id: Date.now().toString(),
    descricao: descricao.trim(),
    valor: Number(Number(valor).toFixed(2)),
    tipo,
    data: new Date().toLocaleDateString('pt-BR')
  };
}

/**
 * Calcula o total de receitas, total de despesas e o saldo atual.
 * @param {Array} transacoes
 */
export function calcularResumo(transacoes) {
  return transacoes.reduce(
    (acc, item) => {
      if (item.tipo === 'receita') {
        acc.receitas += item.valor;
        acc.saldo += item.valor;
      } else if (item.tipo === 'despesa') {
        acc.despesas += item.valor;
        acc.saldo -= item.valor;
      }
      return acc;
    },
    { receitas: 0, despesas: 0, saldo: 0 }
  );
}
