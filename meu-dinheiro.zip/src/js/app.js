import { criarTransacao, calcularResumo } from './financeiro.js';

const STORAGE_KEY = 'meu_dinheiro_transacoes_v1';

const form = document.getElementById('form-transacao');
const inputDescricao = document.getElementById('descricao');
const inputValor = document.getElementById('valor');
const selectTipo = document.getElementById('tipo');
const msgErro = document.getElementById('mensagem-erro');

const elReceitas = document.getElementById('total-receitas');
const elDespesas = document.getElementById('total-despesas');
const elSaldo = document.getElementById('saldo-atual');
const listaTransacoes = document.getElementById('lista-transacoes');

let transacoes = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

function formatarMoeda(valor) {
  return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function salvarDados() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transacoes));
}

function atualizarInterface() {
  const resumo = calcularResumo(transacoes);

  elReceitas.textContent = formatarMoeda(resumo.receitas);
  elDespesas.textContent = formatarMoeda(resumo.despesas);
  elSaldo.textContent = formatarMoeda(resumo.saldo);

  elSaldo.classList.toggle('negativo', resumo.saldo < 0);

  listaTransacoes.innerHTML = '';

  if (transacoes.length === 0) {
    listaTransacoes.innerHTML = '<li class="vazio">Nenhuma movimentação registrada.</li>';
    return;
  }

  transacoes.slice().reverse().forEach((item) => {
    const li = document.createElement('li');
    li.className = `item-transacao ${item.tipo}`;
    li.innerHTML = `
      <div>
        <strong>${item.descricao}</strong>
        <small>${item.data}</small>
      </div>
      <div class="acoes">
        <span>${item.tipo === 'despesa' ? '-' : '+'} ${formatarMoeda(item.valor)}</span>
        <button type="button" data-id="${item.id}" aria-label="Remover">✕</button>
      </div>
    `;
    listaTransacoes.appendChild(li);
  });
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  msgErro.textContent = '';

  try {
    const nova = criarTransacao(inputDescricao.value, inputValor.value, selectTipo.value);
    transacoes.push(nova);
    salvarDados();
    atualizarInterface();
    form.reset();
  } catch (err) {
    msgErro.textContent = err.message;
  }
});

listaTransacoes.addEventListener('click', (event) => {
  if (event.target.tagName === 'BUTTON') {
    const id = event.target.getAttribute('data-id');
    transacoes = transacoes.filter((t) => t.id !== id);
    salvarDados();
    atualizarInterface();
  }
});

atualizarInterface();
