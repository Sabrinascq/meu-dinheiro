import test from 'node:test';
import assert from 'node:assert/strict';
import { validarTransacao, criarTransacao, calcularResumo } from '../src/js/financeiro.js';

test('1. Deve calcular corretamente receitas, despesas e saldo final', () => {
  const lista = [
    { tipo: 'receita', valor: 3000 },
    { tipo: 'despesa', valor: 850.50 },
    { tipo: 'despesa', valor: 149.50 }
  ];

  const resumo = calcularResumo(lista);

  assert.equal(resumo.receitas, 3000);
  assert.equal(resumo.despesas, 1000);
  assert.equal(resumo.saldo, 2000);
});

test('2. Deve criar uma transação válida com valores formatados', () => {
  const transacao = criarTransacao('  Freela Desenvolvimento  ', '1250.5', 'receita');

  assert.equal(transacao.descricao, 'Freela Desenvolvimento');
  assert.equal(transacao.valor, 1250.5);
  assert.equal(transacao.tipo, 'receita');
  assert.ok(transacao.id);
});

test('3. Deve rejeitar transação com valor zero ou negativo', () => {
  const resZero = validarTransacao('Almoço', 0, 'despesa');
  const resNegativo = validarTransacao('Almoço', -50, 'despesa');

  assert.equal(resZero.valido, false);
  assert.equal(resNegativo.valido, false);
  assert.throws(() => criarTransacao('Almoço', -10, 'despesa'));
});

test('4. Deve rejeitar transação com descrição vazia ou muito curta', () => {
  const resVazia = validarTransacao('', 100, 'receita');
  const resCurta = validarTransacao('A', 100, 'receita');

  assert.equal(resVazia.valido, false);
  assert.equal(resCurta.valido, false);
});
