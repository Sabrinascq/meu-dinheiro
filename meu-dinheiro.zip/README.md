# 💰 MeuDinheiro — Operação Deploy

Aplicação web simples de controle financeiro pessoal desenvolvida como projeto prático da disciplina de **Gerência de Configuração e Manutenção de Software**.

---

## 1. Nome e Objetivo da Aplicação
- **Nome:** MeuDinheiro
- **Objetivo:** Permitir que o usuário registre suas receitas e despesas cotidianas de forma rápida, acompanhe o saldo consolidado em tempo real e mantenha um histórico local no navegador, demonstrando na prática um fluxo confiável de integração, testes e entrega contínua (CI/CD).

## 2. Problema que o Sistema Resolve
Muitas pessoas perdem o controle do orçamento mensal por não registrarem pequenas movimentações financeiras ou por dependerem de planilhas complexas. O **MeuDinheiro** resolve esse problema oferecendo uma interface direta para lançar entradas e saídas com validação imediata de dados, evitando registros inconsistentes (como valores negativos ou descrições vazias).

## 3. Integrantes da Equipe e Responsabilidades
*(Preencher com os nomes reais da equipe antes da entrega)*

| Integrante | Papel Principal |
| :--- | :--- |
| **[Nome do Integrante 1]** | Líder de integração (repositório, branches e PRs) |
| **[Nome do Integrante 2]** | Desenvolvedor(a) 1 (regras de negócio e cálculos) |
| **[Nome do Integrante 3]** | Desenvolvedor(a) 2 (interface, validações e localStorage) |
| **[Nome do Integrante 4]** | Responsável por testes (casos de teste e automação) |
| **[Nome do Integrante 5]** | Engenheiro(a) de pipeline (GitHub Actions e deploy) |
| **[Nome do Integrante 6]** | Qualidade e documentação (README, evidências e PDF) |

## 4. Tecnologias Utilizadas
- **HTML5 & CSS3:** Estruturação semântica e estilização responsiva da interface.
- **JavaScript (ES Modules):** Lógica de negócio, manipulação do DOM e persistência via `localStorage`.
- **Node.js (v20) & `node:test`:** Ambiente de execução para scripts de verificação de build e suíte de testes unitários nativos (sem dependências externas).
- **Git & GitHub:** Controle de versão distribuído, gestão de branches e Pull Requests.
- **GitHub Actions:** Orquestração do pipeline de CI/CD.
- **GitHub Pages:** Hospedagem estática da versão validada da aplicação.

## 5. Instruções para Executar a Aplicação Localmente

### Pré-requisitos
- Navegador web moderno (Chrome, Firefox, Edge, etc.).
- [Node.js](https://nodejs.org/) (versão 18 ou superior) instalado para executar os testes e o servidor local.

### Passo a passo
1. Clone o repositório:
   ```bash
   git clone https://github.com/marianagpalacios/meu-dinheiro.git
   cd meu-dinheiro
   ```
2. Inicie um servidor local simples para servir os módulos ES (`src/`):
   ```bash
   npx serve src
   ```
   *(Alternativa: utilize a extensão **Live Server** no VS Code clicando com o botão direito em `src/index.html` > "Open with Live Server").*
3. Acesse no navegador o endereço exibido no terminal (geralmente `http://localhost:3000`).

## 6. Explicação Resumida das Etapas do Pipeline
O pipeline está configurado em `.github/workflows/ci-cd.yml` e é acionado automaticamente a cada `push` ou `pull_request` na branch `main`:
1. **Checkout & Setup:** Baixa o código-fonte do repositório e prepara o ambiente com Node.js 20.
2. **Build (`npm run build`):** Verifica a integridade estrutural da aplicação, garantindo que todos os arquivos essenciais (`index.html`, `style.css`, `financeiro.js`, `app.js`) estejam presentes antes de prosseguir.
3. **Testes Automatizados (`npm test`):** Executa a suíte de testes unitários. Caso qualquer teste falhe, o pipeline é interrompido imediatamente e impede o avanço para a publicação.
4. **Entrega e Publicação (CD):** Executada apenas se o job anterior (`build-and-test`) for concluído com sucesso e o evento for um `push` na `main`. Empacota a pasta `src/` como artefato e realiza o deploy no GitHub Pages.

## 7. Como os Testes são Executados
Os testes automatizados ficam localizados em `tests/financeiro.test.js` e validam as regras reais de negócio (`src/js/financeiro.js`), incluindo cálculo de saldo, formatação de transações e rejeição de entradas inválidas.

Para executá-los localmente via terminal:
```bash
npm test
```

## 8. Como Ocorre a Entrega e a Publicação
- **Entrega Contínua (CD):** Após a aprovação na etapa de CI, o workflow gera um artefato contendo os arquivos estáticos validados da pasta `src/` através da action `actions/upload-pages-artifact`. Em ambientes corporativos, essa etapa deixa o pacote pronto aguardando aprovação manual para produção (Continuous Delivery).
- **Publicação:** Neste projeto, acoplamos a implantação automática no **GitHub Pages** (`actions/deploy-pages`) condicionada estritamente ao sucesso dos testes (`needs: build-and-test`). Se uma alteração quebrar algum teste, o bloqueio ocorre antes da geração do artefato.

## 9. Link para a Aplicação Publicada
- **Aplicação em Produção:** https://marianagpalacios.github.io/meu-dinheiro/ *(Atualizar/confirmar após ativar o GitHub Pages nas configurações do repositório)*

## 10. Limitações Conhecidas do Projeto
- **Armazenamento Local:** Os dados são salvos exclusivamente no `localStorage` do navegador do usuário; limpar os dados do navegador apaga o histórico e não há sincronização entre dispositivos diferentes.
- **Ausência de Autenticação:** Por escopo do projeto, não há sistema de login ou múltiplos perfis de usuário.
- **Categorização Simples:** As movimentações são divididas apenas entre *Receita* e *Despesa*, sem subcategorias (ex.: alimentação, transporte) ou gráficos avançados.
